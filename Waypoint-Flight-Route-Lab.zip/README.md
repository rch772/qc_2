# Waypoint — Flight Route Lab

A browser-based, dependency-free interactive demonstration based on the attached quantum flight trajectory optimization research project. Adjust the synthetic network size and objective weights, then calculate a route with a classical shortest-path algorithm.

## Run locally

Open `index.html` directly, or run a small static server from this folder:

```sh
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Deploy to Vercel

Import this folder as a project in Vercel, or install the Vercel CLI and run `vercel` here. It is a static site with no build step, API keys, environment variables, or runtime dependencies. `vercel.json` sets security response headers including a restrictive Content Security Policy.

## Project summary

Waypoint makes the source research's synthetic waypoint and multi-factor cost model approachable through a small route-planning interface. The included web demo runs a classical shortest-path calculation entirely in the browser. The original Python/Qiskit source is included under `research-source/` for the actual QUBO and QAOA experiments; the static Vercel demo does not execute those experiments.

## Security notes

The web interface has no server-side endpoints, user accounts, persistent storage, third-party scripts, or external network requests. Dynamic labels are inserted as text or escaped, and SVG is built through DOM APIs. Vercel response headers limit framing, content sources, and browser permissions. No security guarantee can be absolute; review hosting settings and dependencies if you extend this project.

## VS Code

Open this folder in VS Code (`code .`). The application source is plain HTML, CSS, and JavaScript.
