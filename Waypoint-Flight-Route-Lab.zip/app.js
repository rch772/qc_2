(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const state = { nodes: [], edges: [], route: [] };
  const esc = (s) => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function rng(seed) { let x = seed >>> 0; return () => { x += 0x6D2B79F5; let t=x; t=Math.imul(t^(t>>>15),t|1); t^=t+Math.imul(t^(t>>>7),t|61); return ((t^(t>>>14))>>>0)/4294967296; }; }
  function generate() {
    const n = Number($('nodes').value), random = rng(Number($('seed').value)||0), pts=[];
    for(let i=0;i<n;i++) pts.push({id:i,x:55+random()*650,y:42+random()*275});
    const edges=[], has=new Set();
    for(let i=0;i<n-1;i++){ const j=i+1; add(i,j); }
    for(let i=0;i<n;i++) for(let j=i+2;j<n;j++) if(random()<.23) add(i,j);
    function add(a,b){if(has.has(`${a}-${b}`))return;has.add(`${a}-${b}`);const dx=pts[a].x-pts[b].x,dy=pts[a].y-pts[b].y,d=Math.hypot(dx,dy)/50;edges.push({a,b,distance:d,fuel:d*(.7+random()*.5),time:d*(.8+random()*.45),weather:random()*d*.7});}
    state.nodes=pts;state.edges=edges;state.route=[];$('networkMeta').textContent=`${n} WAYPOINTS · ${edges.length} AIRWAYS`; draw();$('routeDisplay').textContent='Adjust priorities, then calculate a route.';$('routeTag').textContent='READY';setMetrics(['—','—','—','—']);
  }
  function weights(){const keys=['distance','fuel','time','weather'], vals=keys.map(k=>Number($(k).value)), sum=vals.reduce((a,b)=>a+b,0)||1;keys.forEach((k,i)=>$(k+'Out').textContent=Math.round(vals[i]*100/sum));return Object.fromEntries(keys.map((k,i)=>[k,vals[i]/sum]));}
  function solve(){const w=weights(),n=state.nodes.length,dist=Array(n).fill(Infinity),prev=Array(n).fill(-1),done=Array(n).fill(false);dist[0]=0;
    for(let z=0;z<n;z++){let u=-1;for(let i=0;i<n;i++)if(!done[i]&&(u<0||dist[i]<dist[u]))u=i;if(u<0||!Number.isFinite(dist[u]))break;done[u]=true;if(u===n-1)break;
      for(const e of state.edges){let v=e.a===u?e.b:e.b===u?e.a:-1;if(v<0)continue;const cost=w.distance*e.distance+w.fuel*e.fuel+w.time*e.time+w.weather*e.weather;if(dist[u]+cost<dist[v]){dist[v]=dist[u]+cost;prev[v]=u;}}
    }
    const path=[];for(let at=n-1;at>=0;at=prev[at]){path.push(at);if(at===0)break;}path.reverse();if(path[0]!==0){$('routeDisplay').textContent='No connecting route found.';return;}
    state.route=path;const totals={distance:0,fuel:0,time:0,weather:0};for(let i=1;i<path.length;i++){const e=state.edges.find(e=>(e.a===path[i-1]&&e.b===path[i])||(e.b===path[i-1]&&e.a===path[i]));for(const k in totals)totals[k]+=e[k];}
    $('routeDisplay').innerHTML=path.map((id,i)=>`${i?'<span class="arrow">→</span>':''}<span>${esc('WP'+String(id).padStart(2,'0'))}</span>`).join('');$('routeTag').textContent='CLASSICAL SOLUTION';setMetrics([dist[n-1].toFixed(2),totals.distance.toFixed(1)+' units',totals.fuel.toFixed(1)+' units',totals.time.toFixed(1)+' units']);draw();
  }
  function setMetrics(values){const labels=['TOTAL COST','DISTANCE','EST. FUEL','EST. TIME'];$('metrics').replaceChildren(...values.map((v,i)=>{const box=document.createElement('div'),label=document.createElement('span'),value=document.createElement('strong');label.textContent=labels[i];value.textContent=v;box.append(label,value);return box;}));}
  function draw(){const svg=$('map'), n=state.nodes.length,routePairs=new Set();for(let i=1;i<state.route.length;i++)routePairs.add([state.route[i-1],state.route[i]].sort((a,b)=>a-b).join('-'));svg.replaceChildren();
    const ns='http://www.w3.org/2000/svg';const el=(name,attrs)=>{const x=document.createElementNS(ns,name);for(const k in attrs)x.setAttribute(k,attrs[k]);return x;};
    for(const e of state.edges){const a=state.nodes[e.a],b=state.nodes[e.b],line=el('line',{x1:a.x,y1:a.y,x2:b.x,y2:b.y,class:routePairs.has(`${e.a}-${e.b}`)?'route-edge':'edge'});svg.append(line);}
    for(const p of state.nodes){const group=el('g',{}),circle=el('circle',{cx:p.x,cy:p.y,r:6,class:`node ${p.id===0?'origin':p.id===n-1?'destination':state.route.includes(p.id)?'route-node':''}`}),text=el('text',{x:p.x,y:p.y-12,'text-anchor':'middle',class:'node-label'});text.textContent='WP'+String(p.id).padStart(2,'0');group.append(circle,text);svg.append(group);}
  }
  $('nodes').addEventListener('input',()=>{$('nodesOut').textContent=$('nodes').value;});['distance','fuel','time','weather'].forEach(id=>$(id).addEventListener('input',weights));$('refresh').addEventListener('click',()=>{if(Number($('seed').value)<999999)$('seed').value=Number($('seed').value)+1;generate();});$('seed').addEventListener('change',generate);$('nodes').addEventListener('change',generate);$('solve').addEventListener('click',solve);weights();generate();
})();
