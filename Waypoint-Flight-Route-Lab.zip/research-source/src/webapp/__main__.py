from src.webapp.app import main

if __name__ == "__main__":
    main()
